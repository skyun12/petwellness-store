export default function Home() {
  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h1>Welcome to Vitamin Pet Page</h1>
      <p>건강기능식품 & 반려동물 영양제 쇼핑몰 랜딩페이지입니다.</p>
      <img src="/images/pet-banner.jpg" alt="펫 배너" width="400" />
    </div>
  );
}